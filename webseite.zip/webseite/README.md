# Installation

In this project we use gulp as Taskrunner.
The gulp command line interface (`gulp-cli`) is required:

Installation:

```bash
npm install gulp-cli -g
```
