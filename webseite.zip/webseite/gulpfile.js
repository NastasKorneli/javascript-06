const gulp = require('gulp');
const browserSync = require('browser-sync');
const sass = require('gulp-sass')(require('sass'));
const fileInclude = require('gulp-file-include');
const plumber = require('gulp-plumber');

browserSync.create();

// Static server ===============
gulp.task('server', () => {
  browserSync.init({
    server: {
      baseDir: './',
    },
    open: true,
    port: 3000,
  });
});

gulp.task('reload', (done) => {
  browserSync.reload();
  done();
});

// CSS Task ====================
// - compile scss into css

gulp.task('css', (done) => {
  const sourceFile = './dev/assets/scss/main.scss';
  const targetFolder = './assets/css';

  gulp
    .src(sourceFile)
    .pipe(
      sass({
        outputStyle: 'expanded',
        sourceMap: false,
        debug: true,
      }).on('error', sass.logError)
    )
    .pipe(gulp.dest(targetFolder));

  done(); // Task Prozesse sind fertig.
});

// HTML =================================
gulp.task('html', (done) => {
  const sourceFiles = ['./dev/html/pages/**/*.html', './dev/html/pages/*.html'];
  const targetFolder = './';

  gulp
    .src(sourceFiles)
    .pipe(plumber())
    .pipe(
      fileInclude({
        prefix: '@@',
        basepath: './dev/html/includes',
      })
    )
    .pipe(gulp.dest(targetFolder));

  done();
});

// =============================
// Watch Prozesse ===================

gulp.task('watcher', () => {
  gulp.watch(['./dev/assets/scss/**/*.scss', './dev/assets/scss/*.scss'], gulp.series('css', 'reload'));

  gulp.watch(
    [
      './dev/html/pages/**/*.html',
      './dev/html/pages/*.html',
      './dev/html/includes/**/*.html',
      './dev/html/includes/*.html',
    ],
    gulp.series('html', 'reload')
  );
});

// =============================
// DEVELOPMENT Task
gulp.task('dev', gulp.series('css', 'html', gulp.parallel('watcher', 'server')));

//==============================

gulp.task('test', (done) => {
  console.log('Gulp Task "test" wurde ausgeführt.');
  done();
});
// terminal:
// gulp test

gulp.task('copy', (done) => {
  gulp
    .src('./README.md')
    //.pipe() // Module auf Sourcedateien anwenden
    .pipe(gulp.dest('./docs'));

  done(); // Task Prozesse sind fertig.
});
